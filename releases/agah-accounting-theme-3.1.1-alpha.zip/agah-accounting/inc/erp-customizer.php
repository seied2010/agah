<?php

/** قلم‌های آبی سفارشی‌ساز قالب. */
if(!defined('ABSPATH'))exit;
function agah_theme_customize_partials($manager){
    if(isset($manager->selective_refresh))foreach(['blogname','blogdescription','custom_logo','site_icon'] as $id)$manager->selective_refresh->add_partial($id,['selector'=>'[data-agah="'.$id.'"]','settings'=>[$id],'fallback_refresh'=>true,'render_callback'=>'__return_false']);
    // Every editable theme field has a native blue pencil, including settings without a permanent visible element.
    if(isset($manager->selective_refresh))foreach($manager->settings() as $id=>$setting){
        if(strpos($id,'agah_')!==0&&!in_array($id,['blogname','blogdescription','custom_logo','site_icon'],true))continue;
        if(!$manager->selective_refresh->get_partial($id))$manager->selective_refresh->add_partial($id,['selector'=>'[data-agah="'.$id.'"]','settings'=>[$id],'fallback_refresh'=>true,'render_callback'=>'__return_false']);
    }
}
add_action('customize_register','agah_theme_customize_partials',30);
function agah_preview_settings_anchors(){
    if(!is_customize_preview()||!current_user_can('edit_theme_options'))return;
    global $wp_customize;
    if(!$wp_customize)return;
    echo '<details class="agah-preview-settings"><summary>قلم‌های ویرایش همه تنظیمات قالب</summary><p>برای ویرایش هر مورد روی قلم آبی همان مورد کلیک کنید.</p><div>';
    foreach($wp_customize->controls() as $id=>$control){
        if(strpos($id,'agah_')!==0&&!in_array($id,['blogname','blogdescription','custom_logo','site_icon'],true))continue;
        echo '<span data-agah="'.esc_attr($id).'">'.esc_html($control->label).'</span>';
    }
    echo '</div></details>';
}
add_action('wp_footer','agah_preview_settings_anchors',5);
add_action('wp_head',function(){
    if(is_customize_preview()&&current_user_can('edit_theme_options'))echo '<style>.agah-preview-settings{position:relative;margin:30px;padding:24px;background:#f1f7ff;border:2px solid #1678ba;z-index:100}.agah-preview-settings>div{display:flex;flex-wrap:wrap;gap:28px}.agah-preview-settings span{display:inline-block;padding:10px 30px;min-width:180px}.customize-partial-edit-shortcut button{background:#007cba!important;color:white!important}</style>';
}
);
