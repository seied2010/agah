<?php
declare(strict_types=1);
defined('ABSPATH')||exit;
function agah_public_preferences_enabled():bool{$post=get_post();$id=(int)get_option('agah_erp_page_id');return !is_admin()&&!($id&&is_page($id))&& !($post&&has_shortcode($post->post_content,'agah_erp'));}
add_action('wp_enqueue_scripts',static function(){
    if(!agah_public_preferences_enabled())return;
    $uri=get_template_directory_uri();$v=wp_get_theme()->get('Version');
    wp_enqueue_style('agv-visitor',$uri.'/assets/visitor.css',['agah-style'],$v);
    wp_enqueue_script('agv-visitor',$uri.'/assets/js/visitor.js',[],$v,true);
});
add_action('wp_head',static function(){
    if(!agah_public_preferences_enabled())return;
    // Public appearance has its own storage; account/dashboard preferences remain independent.
    echo '<script>(function(){var s="light";try{var p=JSON.parse(localStorage.getItem("agv-public-preferences")||"{}");if(p.scheme==="dark")s="dark";}catch(e){}document.documentElement.dataset.agvPublic="";document.documentElement.dataset.theme=s;})();</script>';
},1);
add_action('wp_footer',static function(){
    if(!agah_public_preferences_enabled())return;
    ?>
    <div class="agv-visitor-dock" aria-label="تنظیمات نمایش صفحه">
      <button type="button" data-agv-panel="agv-personal-panel" aria-controls="agv-personal-panel" aria-expanded="false">☷ <span>شخصی‌سازی صفحه</span></button>
      <button type="button" id="agv-theme-toggle" aria-pressed="false" aria-label="تغییر حالت روشن و تیره">◐ روشن / تیره</button>
      <button type="button" data-agv-panel="agv-a11y-panel" aria-controls="agv-a11y-panel" aria-expanded="false">Aa <span>دسترس‌پذیری</span></button>
    </div>
    <section id="agv-personal-panel" class="agv-visitor-panel" role="dialog" aria-labelledby="agv-personal-title" hidden>
      <header><h2 id="agv-personal-title">شخصی‌سازی صفحه</h2><button type="button" data-agv-close aria-label="بستن شخصی‌سازی">×</button></header>
      <label>حالت نمایش<select data-agv-pref="scheme"><option value="light">روشن (پیش‌فرض)</option><option value="dark">تیره</option></select></label>
      <label>رنگ اصلی<select data-agv-pref="color"><option value="default">پیش‌فرض سایت</option><option value="gold">طلایی</option><option value="green">سبز</option><option value="blue">آبی</option><option value="purple">بنفش</option></select></label>
      <label>فونت<select data-agv-pref="font"><option value="default">پیش‌فرض سایت</option><option value="tahoma">Tahoma</option><option value="arial">Arial</option></select></label>
      <label>اندازهٔ متن <output id="agv-size-label" aria-live="polite">۱۰۰٪</output><input data-agv-pref="size" aria-describedby="agv-size-label" type="range" min="90" max="140" step="5" value="100"></label>
      <button type="button" data-agv-reset="personal">بازگشت به پیش‌فرض روشن</button>
    </section>
    <section id="agv-a11y-panel" class="agv-visitor-panel" role="dialog" aria-labelledby="agv-a11y-title" hidden>
      <header><h2 id="agv-a11y-title">دسترس‌پذیری</h2><button type="button" data-agv-close aria-label="بستن دسترس‌پذیری">×</button></header>
      <?php foreach(['contrast'=>'کنتراست بالا','spacing'=>'فاصلهٔ بیشتر خطوط و کلمات','motion'=>'کاهش حرکت و انیمیشن','readable'=>'فونت خوانا (بدون تزئین)'] as $key=>$label): ?>
      <button type="button" data-agv-access="<?php echo esc_attr($key); ?>" aria-pressed="false"><?php echo esc_html($label); ?></button>
      <?php endforeach; ?><button type="button" data-agv-reset="access">بازنشانی دسترس‌پذیری</button>
    </section>
    <?php
});
