(()=>{'use strict';const root=document.documentElement;if(!root.hasAttribute('data-agv-public'))return;
const defaults={scheme:'light',color:'default',font:'default',size:100,contrast:false,spacing:false,motion:false,readable:false};let state={...defaults};
try{const p=JSON.parse(localStorage.getItem('agv-public-preferences')||'{}');for(const k of Object.keys(defaults))if(Object.hasOwn(p,k))state[k]=p[k];}catch(e){}
const palette={gold:['#a77735','#d9b377'],green:['#23654a','#8cd5ae'],blue:['#2459a0','#99bdf2'],purple:['#754099','#d3a5f0']};
function apply(){
state.scheme=state.scheme==='dark'?'dark':'light';root.dataset.theme=state.scheme;
if(!['default','tahoma','arial'].includes(state.font))state.font='default';root.dataset.agvFont=state.font;
state.size=Number(state.size);if(!Number.isFinite(state.size))state.size=100;state.size=Math.max(90,Math.min(140,state.size));root.style.fontSize=(16*state.size/100)+'px';root.style.setProperty('--agv-font-size',(16*state.size/100)+'px');
if(palette[state.color])root.style.setProperty('--c-brand',palette[state.color][state.scheme==='dark'?1:0]);else{state.color='default';root.style.removeProperty('--c-brand');}
for(const key of ['contrast','spacing','motion','readable']){state[key]=state[key]===true;root.dataset['agv'+key[0].toUpperCase()+key.slice(1)]=String(state[key]);}
document.querySelectorAll('[data-agv-pref]').forEach(el=>el.value=state[el.dataset.agvPref]);document.querySelectorAll('[data-agv-access]').forEach(el=>el.setAttribute('aria-pressed',String(state[el.dataset.agvAccess])));
document.getElementById('agv-size-label').textContent=state.size+'٪';document.getElementById('agv-theme-toggle')?.setAttribute('aria-pressed',String(state.scheme==='dark'));
try{localStorage.setItem('agv-public-preferences',JSON.stringify(state));}catch(e){}
}
let active=null;function close(){if(!active)return;const id=active.id;active.hidden=true;document.querySelectorAll('[aria-controls="'+id+'"]').forEach(b=>b.setAttribute('aria-expanded','false'));active=null;}
function toggle(id,button){const panel=document.getElementById(id);if(!panel)return;const open=panel!==active;close();if(open){panel.hidden=false;active=panel;button.setAttribute('aria-expanded','true');panel.querySelector('button,select,input')?.focus();}}
document.querySelectorAll('[data-agv-panel]').forEach(b=>b.addEventListener('click',()=>toggle(b.dataset.agvPanel,b)));
document.querySelectorAll('[data-agv-close]').forEach(b=>b.addEventListener('click',()=>{const id=b.closest('section').id;close();document.querySelector('[data-agv-panel="'+id+'"]')?.focus();}));
document.querySelectorAll('[data-agv-pref]').forEach(el=>el.addEventListener('input',()=>{state[el.dataset.agvPref]=el.value;apply();}));
document.querySelectorAll('[data-agv-access]').forEach(b=>b.addEventListener('click',()=>{state[b.dataset.agvAccess]=!state[b.dataset.agvAccess];apply();}));
document.querySelectorAll('[data-agv-reset]').forEach(b=>b.addEventListener('click',()=>{for(const k of b.dataset.agvReset==='access'?['contrast','spacing','motion','readable']:['scheme','color','font','size'])state[k]=defaults[k];apply();}));
document.getElementById('agv-theme-toggle')?.addEventListener('click',()=>{state.scheme=state.scheme==='dark'?'light':'dark';apply();});
// Keep the existing header accessibility button as another entrance to the new panel.
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&active){const id=active.id;close();document.querySelector('[data-agv-panel="'+id+'"]')?.focus();}});
document.addEventListener('pointerdown',e=>{if(active&&!e.target.closest('.agv-visitor-panel,.agv-visitor-dock,#agv-access-toggle'))close();});apply();
})();
