<?php

/**
 * پشتیبان قابل‌دریافت شرکت‌ها.
 *
 * فایل خروجی با گذرواژهٔ انتخابی کاربر و secretbox رمز می‌شود، مسیر عمومی وب ندارد
 * و رکوردهای باینری مانند پیوست‌ها را نیز عیناً نگه می‌دارد. بازیابی وبی عمداً وجود ندارد؛
 * inspect برای کنترل اصالت و ابزار خط فرمان برای تحویل به پشتیبان فنی فراهم است.
 */
namespace Agah\Erp\Modules\Maintenance;

use Agah\Erp\Core\{Audit,Crypto,Db,Schema,ValidationException,ConflictException,NotFoundException};

if ( ! defined( 'ABSPATH' ) ) exit;

final class PortableBackupService {
    const MAGIC = "AGAH-PORTABLE-1\n";
    const FORMAT = 1;
    const EXT = 'agahbackup';
    private const EXCLUDED = array( 'auth_states', 'rate_limits', 'login_otp', 'idempotency' );

    private static function limit() {
        return defined( 'AGAH_PORTABLE_BACKUP_MAX_BYTES' )
            ? max( 1048576, min( 268435456, (int) AGAH_PORTABLE_BACKUP_MAX_BYTES ) )
            : 67108864;
    }

    private static function memoryBudget() {
        $v = trim( (string) ini_get( 'memory_limit' ) );
        if ( '' === $v || '-1' === $v ) return 0;
        $n = (int) $v;
        $suffix = strtolower( substr( $v, -1 ) );
        if ( 'g' === $suffix ) $n *= 1073741824;
        elseif ( 'm' === $suffix ) $n *= 1048576;
        elseif ( 'k' === $suffix ) $n *= 1024;
        return $n;
    }

    private static function password( $password ) {
        if ( ! is_string( $password ) || strlen( $password ) < 12 || strlen( $password ) > 200 ) {
            throw new ValidationException( array( 'backup_password' => 'گذرواژهٔ فایل باید بین ۱۲ تا ۲۰۰ نویسه باشد.' ) );
        }
        return $password;
    }

    private static function key( $password, $salt ) {
        self::password( $password );
        try {
            return sodium_crypto_pwhash(
                SODIUM_CRYPTO_SECRETBOX_KEYBYTES,
                $password,
                $salt,
                SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
                SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE,
                SODIUM_CRYPTO_PWHASH_ALG_DEFAULT
            );
        } catch ( \Throwable $e ) {
            throw new ValidationException( array( 'backup' => 'حافظهٔ لازم برای رمزگذاری امن فایل در دسترس نیست.' ) );
        }
    }

    /** اطلاعات ستون و کلید اصلی فقط برای جدول‌های همین نسخه. */
    private static function metadata() {
        global $wpdb;
        $actual = Db::col( 'SHOW TABLES LIKE %s', $wpdb->esc_like( Db::t( '' ) ) . '%' );
        $expected = array_map( array( Db::class, 't' ), Schema::tables() );
        sort( $actual );
        sort( $expected );
        if ( $actual !== $expected ) {
            throw new ValidationException( array( 'backup' => 'ساختار پایگاه داده با نسخهٔ افزونه تطبیق ندارد؛ ابتدا سلامت سامانه را بررسی کنید.' ) );
        }
        $out = array();
        foreach ( Schema::tables() as $table ) {
            $columns = Db::rows( 'SHOW COLUMNS FROM ' . Db::t( $table ) );
            $out[ $table ] = array(
                'columns' => array_column( $columns, 'Field' ),
                'primary' => array(),
            );
            foreach ( Db::rows( 'SHOW INDEX FROM ' . Db::t( $table ) . " WHERE Key_name='PRIMARY'" ) as $row ) {
                $out[ $table ]['primary'][] = $row['Column_name'];
            }
            if ( ! $out[ $table ]['primary'] ) {
                throw new ValidationException( array( 'backup' => 'جدول بدون کلید اصلی قابل پشتیبان‌گیری امن نیست.' ) );
            }
        }
        return $out;
    }

    private static function selected( $table, array $meta, $scope ) {
        if ( in_array( $table, self::EXCLUDED, true ) ) return false;
        if ( 'all' === $scope ) return true;
        return 'companies' === $table || 'role_caps' === $table || in_array( 'company_id', $meta['columns'], true );
    }

    private static function query( $table, array $meta, $scope, $cid, $limit, $offset ) {
        $order = implode( ',', array_map( function( $column ) { return '`' . $column . '`'; }, $meta['primary'] ) );
        $physical = Db::t( $table );
        if ( 'all' === $scope ) {
            return Db::rows( 'SELECT * FROM ' . $physical . ' ORDER BY ' . $order . ' LIMIT %d OFFSET %d', $limit, $offset );
        }
        if ( 'companies' === $table ) {
            return Db::rows( 'SELECT * FROM ' . $physical . ' WHERE id=%d ORDER BY ' . $order . ' LIMIT %d OFFSET %d', $cid, $limit, $offset );
        }
        if ( 'role_caps' === $table ) {
            return Db::rows( 'SELECT rc.* FROM ' . $physical . ' rc JOIN ' . Db::t( 'roles' ) . ' r ON r.id=rc.role_id WHERE r.company_id=%d ORDER BY rc.role_id,rc.cap LIMIT %d OFFSET %d', $cid, $limit, $offset );
        }
        if ( in_array( 'company_id', $meta['columns'], true ) ) {
            return Db::rows( 'SELECT * FROM ' . $physical . ' WHERE company_id=%d ORDER BY ' . $order . ' LIMIT %d OFFSET %d', $cid, $limit, $offset );
        }
        return array();
    }

    private static function capture( $scope, $cid ) {
        return Db::tx( function() use ( $scope, $cid ) {
            if ( 'company' === $scope ) {
                $company = Db::row( 'SELECT id,uuid,name,status FROM ' . Db::t( 'companies' ) . ' WHERE id=%d FOR UPDATE', $cid );
                if ( ! $company ) throw new NotFoundException();
                $companies = array( $company );
            } else {
                $companies = Db::rows( 'SELECT id,uuid,name,status FROM ' . Db::t( 'companies' ) . ' ORDER BY id FOR UPDATE' );
                if ( ! $companies ) throw new ConflictException( 'شرکتی برای پشتیبان‌گیری وجود ندارد.' );
            }

            $metadata = self::metadata();
            $tables = array();
            $counts = array();
            $size = 0;
            foreach ( $metadata as $table => $meta ) {
                if ( ! self::selected( $table, $meta, $scope ) ) continue;
                $rows = array();
                $step = in_array( $table, array( 'files', 'expense_images', 'company_archive_chunks' ), true ) ? 1 : 100;
                $offset = 0;
                do {
                    $batch = self::query( $table, $meta, $scope, $cid, $step, $offset );
                    foreach ( $batch as $row ) {
                        $encoded = array();
                        foreach ( $meta['columns'] as $column ) {
                            $value = $row[ $column ];
                            $encoded[] = null === $value ? null : base64_encode( (string) $value );
                            $size += null === $value ? 4 : strlen( (string) $value ) * 2 + 8;
                        }
                        $budget = self::memoryBudget();
                        if ( $size > self::limit() || ( $budget > 0 && memory_get_usage( true ) + $size * 4 > $budget - 16777216 ) ) {
                            throw new ValidationException( array( 'backup' => 'حجم اطلاعات از سقف پشتیبان قابل‌دریافت بیشتر است؛ پشتیبان سرور لازم است.' ) );
                        }
                        $rows[] = $encoded;
                    }
                    $offset += $step;
                } while ( count( $batch ) === $step );
                $tables[ $table ] = array( 'columns' => $meta['columns'], 'rows' => $rows );
                $counts[ $table ] = count( $rows );
            }

            $users = array();
            global $wpdb;
            foreach ( Db::rows( 'SELECT ID,user_login FROM ' . $wpdb->users . ' ORDER BY ID' ) as $user ) {
                $users[ (string) $user['ID'] ] = hash( 'sha256', $user['user_login'] );
            }
            return array(
                'format' => self::FORMAT,
                'schema' => Schema::VERSION,
                'plugin' => defined( 'AGAH_ERP_VERSION' ) ? AGAH_ERP_VERSION : '',
                'scope' => $scope,
                'created_at' => gmdate( 'c' ),
                'source' => hash( 'sha256', untrailingslashit( home_url() ) ),
                'crypto_probe' => Crypto::encrypt( 'agah-portable-backup-key-check' ),
                'companies' => $companies,
                'users' => $users,
                'counts' => $counts,
                'tables' => $tables,
            );
        } );
    }

    private static function seal( array $data, $password ) {
        $json = wp_json_encode( $data, JSON_UNESCAPED_UNICODE );
        if ( ! is_string( $json ) || strlen( $json ) > self::limit() * 2 ) {
            throw new ValidationException( array( 'backup' => 'ساخت فایل پشتیبان کامل نشد.' ) );
        }
        $compressed = gzcompress( $json, 6 );
        if ( false === $compressed ) throw new ConflictException( 'فشرده‌سازی فایل پشتیبان در این سرور در دسترس نیست.' );
        $salt = random_bytes( SODIUM_CRYPTO_PWHASH_SALTBYTES );
        $nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
        $key = self::key( $password, $salt );
        $cipher = sodium_crypto_secretbox( $compressed, $nonce, $key );
        sodium_memzero( $key );
        return self::MAGIC . $salt . $nonce . $cipher;
    }

    /** @return array{name:string,bytes:string,sha256:string,counts:array,scope:string,companies:array} */
    public static function create( $scope, $cid, $password ) {
        if ( ! in_array( $scope, array( 'company', 'all' ), true ) ) throw new ValidationException( array( 'scope' => 'دامنهٔ پشتیبان معتبر نیست.' ) );
        if ( 'company' === $scope && (int) $cid < 1 ) throw new ValidationException( array( 'scope' => 'شرکت مشخص نشده است.' ) );
        if ( BackupService::blocked() ) throw new ConflictException( 'بازیابی سامانه در حال اجراست.' );
        self::password( $password );
        $data = self::capture( $scope, (int) $cid );
        $bytes = self::seal( $data, $password );
        if ( strlen( $bytes ) > self::limit() ) throw new ValidationException( array( 'backup' => 'فایل نهایی از سقف مجاز بزرگ‌تر است.' ) );
        $sha = hash( 'sha256', $bytes );
        $rows = array_sum( $data['counts'] );
        $auditCid = 'company' === $scope ? (int) $cid : 0;
        Audit::log( 'backup.export', 'backup', 0, null, array( 'scope' => $scope, 'sha256' => $sha, 'tables' => count( $data['tables'] ), 'rows' => $rows ), $auditCid );
        $stamp = gmdate( 'Ymd-His' );
        $name = 'company' === $scope ? 'agah-company-' . (int) $cid . '-' . $stamp : 'agah-all-companies-' . $stamp;
        return array( 'name' => $name . '.' . self::EXT, 'bytes' => $bytes, 'sha256' => $sha, 'counts' => $data['counts'], 'scope' => $scope, 'companies' => $data['companies'] );
    }

    /** رمزگشایی و کنترل اصالت، بدون تغییر هیچ داده‌ای. */
    public static function inspectBytes( $bytes, $password ) {
        if ( ! is_string( $bytes ) || strlen( $bytes ) > self::limit() || strlen( $bytes ) < strlen( self::MAGIC ) + SODIUM_CRYPTO_PWHASH_SALTBYTES + SODIUM_CRYPTO_SECRETBOX_NONCEBYTES + SODIUM_CRYPTO_SECRETBOX_MACBYTES ) {
            throw new ValidationException( array( 'backup' => 'اندازه یا قالب فایل پشتیبان معتبر نیست.' ) );
        }
        $head = strlen( self::MAGIC );
        if ( substr( $bytes, 0, $head ) !== self::MAGIC ) throw new ValidationException( array( 'backup' => 'این فایل پشتیبان آگاه نیست.' ) );
        $salt = substr( $bytes, $head, SODIUM_CRYPTO_PWHASH_SALTBYTES );
        $nonceAt = $head + SODIUM_CRYPTO_PWHASH_SALTBYTES;
        $nonce = substr( $bytes, $nonceAt, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
        $cipher = substr( $bytes, $nonceAt + SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
        $key = self::key( $password, $salt );
        $compressed = sodium_crypto_secretbox_open( $cipher, $nonce, $key );
        sodium_memzero( $key );
        if ( false === $compressed ) throw new ValidationException( array( 'backup_password' => 'گذرواژه نادرست است یا فایل دستکاری شده است.' ) );
        $json = @gzuncompress( $compressed, self::limit() * 2 );
        if ( false === $json ) throw new ValidationException( array( 'backup' => 'محتوای فشردهٔ فایل معتبر نیست.' ) );
        $data = json_decode( $json, true, 512, JSON_BIGINT_AS_STRING );
        if ( ! is_array( $data ) || ( $data['format'] ?? null ) !== self::FORMAT || ! in_array( $data['scope'] ?? '', array( 'company', 'all' ), true ) || ! is_array( $data['tables'] ?? null ) || ! is_array( $data['counts'] ?? null ) || ! is_array( $data['companies'] ?? null ) ) {
            throw new ValidationException( array( 'backup' => 'ساختار داخلی فایل معتبر نیست.' ) );
        }
        foreach ( $data['tables'] as $table => $definition ) {
            if ( ! in_array( $table, Schema::tables(), true ) || ! is_array( $definition['columns'] ?? null ) || ! is_array( $definition['rows'] ?? null ) || (int) ( $data['counts'][ $table ] ?? -1 ) !== count( $definition['rows'] ) ) {
                throw new ValidationException( array( 'backup' => 'فهرست جدول‌ها یا تعداد ردیف‌ها معتبر نیست.' ) );
            }
            foreach ( $definition['rows'] as $row ) {
                if ( ! is_array( $row ) || count( $row ) !== count( $definition['columns'] ) ) throw new ValidationException( array( 'backup' => 'یک ردیف ناقص در فایل وجود دارد.' ) );
                foreach ( $row as $value ) if ( null !== $value && ( ! is_string( $value ) || false === base64_decode( $value, true ) ) ) throw new ValidationException( array( 'backup' => 'یک مقدار نامعتبر در فایل وجود دارد.' ) );
            }
        }
        return array(
            'format' => $data['format'],
            'schema' => (string) ( $data['schema'] ?? '' ),
            'plugin' => (string) ( $data['plugin'] ?? '' ),
            'scope' => $data['scope'],
            'created_at' => (string) ( $data['created_at'] ?? '' ),
            'companies' => $data['companies'],
            'counts' => $data['counts'],
            'same_installation_key' => Crypto::decrypt( (string) ( $data['crypto_probe'] ?? '' ) ) === 'agah-portable-backup-key-check',
            'sha256' => hash( 'sha256', $bytes ),
        );
    }

    public static function inspectFile( $path, $password ) {
        if ( ! is_string( $path ) || ! is_file( $path ) || is_link( $path ) || filesize( $path ) > self::limit() ) throw new ValidationException( array( 'backup' => 'فایل پشتیبان معتبر نیست.' ) );
        $bytes = file_get_contents( $path );
        if ( false === $bytes ) throw new ValidationException( array( 'backup' => 'خواندن فایل پشتیبان ناموفق بود.' ) );
        return self::inspectBytes( $bytes, $password );
    }

    /** اعتبارسنجی پشتیبان بدون قراردادن گذرواژه در تاریخچهٔ فرمان. */
    public static function register() {
        if ( ! ( defined( 'WP_CLI' ) && WP_CLI ) ) return;
        \WP_CLI::add_command( 'agah portable-backup', function( $args, $assoc ) {
            try {
                $action = $args[0] ?? 'verify';
                if ( 'verify' !== $action || empty( $args[1] ) ) \WP_CLI::error( 'Usage: wp agah portable-backup verify FILE --password-env=ENV_NAME' );
                $envName = isset( $assoc['password-env'] ) ? (string) $assoc['password-env'] : '';
                if ( ! preg_match( '/^[A-Z][A-Z0-9_]{2,60}$/D', $envName ) ) \WP_CLI::error( 'A safe --password-env name is required.' );
                $password = getenv( $envName );
                if ( ! is_string( $password ) || '' === $password ) \WP_CLI::error( 'Password environment variable is empty.' );
                $result = self::inspectFile( (string) $args[1], $password );
                unset( $password );
                \WP_CLI::line( wp_json_encode( $result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) );
                \WP_CLI::success( 'Portable backup is authentic; no data was changed.' );
            } catch ( \Throwable $e ) {
                error_log( '[agah-portable-backup-cli] ' . get_class( $e ) );
                \WP_CLI::error( $e instanceof ValidationException ? implode( ' ', $e->errors ) : 'Portable backup verification failed.' );
            }
        } );
    }

    public static function maxBytes() { return self::limit(); }
}
