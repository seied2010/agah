$ErrorActionPreference = 'Stop'
$program = Split-Path $PSScriptRoot -Parent
$root = Split-Path $program -Parent
$state = Join-Path $root 'state'
$logs = Join-Path $state 'logs'
$php = Join-Path $program 'runtime\php\php.exe'
$database = Join-Path $program 'runtime\mariadb'
$app = Join-Path $program 'app'
$webPort = 18817
$dbPort = 33417
$mutex = New-Object Threading.Mutex($false, 'Local\AgahLocalPrototype01')
if (-not $mutex.WaitOne(0)) { Write-Host 'Agah Local is already running. Open http://127.0.0.1:18817/'; Start-Process 'http://127.0.0.1:18817/'; exit 0 }
$dbProcess = $null; $webProcess = $null; $failed = $false
function Write-Utf8($path, $value) { [IO.File]::WriteAllText($path, $value, (New-Object Text.UTF8Encoding($false))) }
function Quote-Arg($value) { return '"' + ($value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"' }
function Is-PortOpen($port) {
    $tcp = New-Object Net.Sockets.TcpClient
    try { $task = $tcp.ConnectAsync('127.0.0.1', $port); return ($task.Wait(200) -and $tcp.Connected) } catch { return $false } finally { $tcp.Dispose() }
}
function New-Secret {
    $bytes = New-Object byte[] 32
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes); return ([BitConverter]::ToString($bytes)).Replace('-','').ToLowerInvariant() } finally { $rng.Dispose() }
}
try {
    if (-not (Test-Path (Join-Path $program 'installed.ok'))) { throw 'Run Install.cmd from the extracted ZIP first.' }
    New-Item -ItemType Directory -Path $state,$logs -Force | Out-Null
    if ((Is-PortOpen $webPort) -or (Is-PortOpen $dbPort)) { throw 'A required local port (18817 or 33417) is already in use. Close the previous Agah Local instance; no other program was stopped.' }
    $stop = Join-Path $state 'stop.request'
    if (Test-Path $stop) { Remove-Item -LiteralPath $stop }
    $settingsPath = Join-Path $state 'settings.json'
    if (-not (Test-Path $settingsPath)) {
        if (Test-Path (Join-Path $state 'db')) { throw 'Database exists without its settings/key file. Restore the whole installation backup.' }
        $settings = @{ root_password=(New-Secret); db_password=(New-Secret); admin_password=(New-Secret); enc_key=(New-Secret); salts=(New-Secret)+(New-Secret); db_host='127.0.0.1'; db_port=$dbPort; url="http://127.0.0.1:$webPort" }
        Write-Utf8 $settingsPath ($settings | ConvertTo-Json)
    }
    $settings = Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
    # DLL/extension preflight occurs before any database is created.
    & $php -c (Join-Path $PSScriptRoot 'php.ini') -d ('extension_dir=' + (Join-Path $program 'runtime\php\ext')) (Join-Path $PSScriptRoot 'preflight.php')
    if ($LASTEXITCODE -ne 0) { throw 'PHP preflight failed. See console output; no download will be attempted.' }
    $data = Join-Path $state 'db'
    if (-not (Test-Path (Join-Path $data 'mysql'))) {
        if (Test-Path $data) { throw 'Partial database initialization detected. Preserve state and consult init logs before retrying.' }
        $init = Start-Process -FilePath (Join-Path $database 'bin\mariadb-install-db.exe') -ArgumentList @((Quote-Arg "--datadir=$data"), (Quote-Arg ('--password=' + $settings.root_password)), "--port=$dbPort") -WorkingDirectory $database -PassThru -Wait -NoNewWindow -RedirectStandardOutput (Join-Path $logs 'db-init.log') -RedirectStandardError (Join-Path $logs 'db-init-error.log')
        if ($init.ExitCode -ne 0) { throw 'Database initialization failed. Read state\logs\db-init-error.log.' }
    }
    $baseIni = $database.Replace('\','/')
    $dataIni = $data.Replace('\','/')
    $serverIni = "[mysqld]`nbasedir=$baseIni`ndatadir=$dataIni`nport=$dbPort`nbind-address=127.0.0.1`nskip-name-resolve`ncharacter-set-server=utf8mb4`ncollation-server=utf8mb4_unicode_ci`ninnodb-buffer-pool-size=128M`nmax-connections=20`nlocal-infile=0`n"
    Write-Utf8 (Join-Path $state 'server.ini') $serverIni
    Write-Utf8 (Join-Path $state 'client.ini') ("[client]`nuser=root`npassword="+$settings.root_password+"`nhost=127.0.0.1`nport=$dbPort`nprotocol=tcp`n")
    $dbProcess = Start-Process -FilePath (Join-Path $database 'bin\mariadbd.exe') -ArgumentList @((Quote-Arg ('--defaults-file=' + (Join-Path $state 'server.ini'))), '--console') -WorkingDirectory $database -PassThru -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'db.log') -RedirectStandardError (Join-Path $logs 'db-error.log')
    for ($i=0; $i -lt 80; $i++) { if (Is-PortOpen $dbPort) { break }; if ($dbProcess.HasExited) { throw 'Database exited. Read state\logs\db-error.log.' }; Start-Sleep -Milliseconds 250 }
    if (-not (Is-PortOpen $dbPort)) { throw 'Database startup timed out.' }
    & $php -c (Join-Path $PSScriptRoot 'php.ini') -d ('extension_dir=' + (Join-Path $program 'runtime\php\ext')) (Join-Path $PSScriptRoot 'initialize.php') $state
    if ($LASTEXITCODE -ne 0) { throw 'Local setup failed. Your files were preserved; review the console error.' }
    $phpArgs = @('-c',(Quote-Arg (Join-Path $PSScriptRoot 'php.ini')),'-d',(Quote-Arg ('extension_dir=' + (Join-Path $program 'runtime\php\ext'))),'-S',"127.0.0.1:$webPort",'-t',(Quote-Arg $app),(Quote-Arg (Join-Path $PSScriptRoot 'router.php')))
    $webProcess = Start-Process -FilePath $php -ArgumentList $phpArgs -WorkingDirectory $app -PassThru -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'web.log') -RedirectStandardError (Join-Path $logs 'web-error.log')
    for ($i=0; $i -lt 40; $i++) { if (Is-PortOpen $webPort) { break }; if ($webProcess.HasExited) { throw 'Local web runtime exited. Read state\logs\web-error.log.' }; Start-Sleep -Milliseconds 250 }
    if (-not (Is-PortOpen $webPort)) { throw 'Local web runtime startup timed out.' }
    if (Test-Path (Join-Path $state 'FIRST-LOGIN.txt')) { Start-Process notepad.exe -ArgumentList (Quote-Arg (Join-Path $state 'FIRST-LOGIN.txt')) }
    Start-Process ($settings.url + '/?page_id=' + [IO.File]::ReadAllText((Join-Path $state 'page-id.txt')).Trim())
    Write-Host 'Agah Local Prototype is running OFFLINE on this PC only.'
    Write-Host "Data and key files: $root"
    Write-Host 'Use Stop.cmd or Ctrl+C for a clean shutdown. Keep this console open.'
    while (-not (Test-Path $stop)) { if ($dbProcess.HasExited -or $webProcess.HasExited) { throw 'A local runtime stopped. Inspect state\logs.' }; Start-Sleep -Seconds 1 }
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; $failed=$true }
finally {
    if ($webProcess -and -not $webProcess.HasExited) { $webProcess.Kill(); $webProcess.WaitForExit(5000) | Out-Null }
    if ($dbProcess -and -not $dbProcess.HasExited) {
        & (Join-Path $database 'bin\mariadb-admin.exe') ("--defaults-extra-file=" + (Join-Path $state 'client.ini')) shutdown 2>&1 | Out-Null
        if (-not $dbProcess.WaitForExit(15000)) { Write-Host 'Database is still shutting down. Do not remove or copy its files yet.' }
    }
    $mutex.ReleaseMutex(); $mutex.Dispose()
}
if ($failed) { exit 1 }
