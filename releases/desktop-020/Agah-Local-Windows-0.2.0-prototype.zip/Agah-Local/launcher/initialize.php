<?php
// Local first-run setup; never served over HTTP.
if(PHP_SAPI!=='cli')exit;
try{
    $state=$argv[1]??'';$app=dirname(__DIR__).'/app';
    $s=json_decode(file_get_contents($state.'/settings.json'),true,512,JSON_THROW_ON_ERROR);
    mysqli_report(MYSQLI_REPORT_ERROR|MYSQLI_REPORT_STRICT);
    $db=new mysqli($s['db_host'],'root',$s['root_password'],'',(int)$s['db_port']);
    $db->query('CREATE DATABASE IF NOT EXISTS agah_local CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $password=$db->real_escape_string($s['db_password']);
    $db->query("CREATE USER IF NOT EXISTS 'agah_local'@'127.0.0.1' IDENTIFIED BY '$password'");
    $db->query("CREATE USER IF NOT EXISTS 'agah_local'@'localhost' IDENTIFIED BY '$password'");
    $db->query("GRANT ALL ON agah_local.* TO 'agah_local'@'127.0.0.1'");
    $db->query("GRANT ALL ON agah_local.* TO 'agah_local'@'localhost'");$db->close();
    // Keep this configuration in state so reinstalling program files cannot replace the data key.
    if(!file_exists($state.'/wp-settings-local.php'))copy(__DIR__.'/local-config.php',$state.'/wp-settings-local.php');
    $statePath=var_export(str_replace('\\','/',$state).'/wp-settings-local.php',true);
    if(!file_exists($app.'/wp-config.php'))file_put_contents($app.'/wp-config.php',"<?php\nrequire $statePath;\nif(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');\nrequire_once ABSPATH.'wp-settings.php';\n");
    $_SERVER['HTTP_HOST']=parse_url($s['url'],PHP_URL_HOST).':'.parse_url($s['url'],PHP_URL_PORT);
    $_SERVER['SERVER_NAME']=parse_url($s['url'],PHP_URL_HOST);$_SERVER['REQUEST_URI']='/';$_SERVER['REQUEST_METHOD']='GET';
    define('WP_INSTALLING',true);require $app.'/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';
    if(!is_blog_installed()){
        $result=wp_install('حسابداری آگاه — نسخهٔ محلی','agah','local@agah.invalid',false,'',$s['admin_password']);
        if(is_wp_error($result))throw new RuntimeException('WordPress installation failed.');
        file_put_contents($state.'/FIRST-LOGIN.txt',"Agah Local Prototype\r\nLocal address: ".$s['url']."\r\nUsername: agah\r\nInitial password: ".$s['admin_password']."\r\nChange this password in your account, then remove this file.\r\n");
    }
    wp_installing(false);switch_theme('agah-accounting');$admin=get_user_by('login','agah');
    if(!$admin)throw new RuntimeException('Local administrator account is missing.');
    wp_set_current_user($admin->ID);require_once ABSPATH.'wp-admin/includes/plugin.php';
    if(!is_plugin_active('agah-erp/agah-erp.php')){$r=activate_plugin('agah-erp/agah-erp.php');if(is_wp_error($r))throw new RuntimeException('Agah activation failed.');}
    else require_once WP_PLUGIN_DIR.'/agah-erp/agah-erp.php';
    if(!function_exists('agah_erp_activate'))throw new RuntimeException('Agah plugin did not load.');
    agah_erp_activate();
    if(!\Agah\Erp\Core\Db::val('SELECT id FROM '.\Agah\Erp\Core\Db::t('companies').' WHERE owner_user_id=%d',$admin->ID)){
        \Agah\Erp\Modules\Company\CompanyService::create($admin->ID,['name'=>'شرکت محلی آزمایشی','kind'=>'legal','display_unit'=>'rial','jy'=>\Agah\Erp\Core\Jalali::currentYear()]);
    }
    update_option('blog_public','0');update_option('permalink_structure','');update_option('show_avatars',0);update_option('timezone_string','Asia/Tehran');
    file_put_contents($state.'/page-id.txt',(string)get_option('agah_erp_page_id'));
    file_put_contents($state.'/setup.complete','0.1.0');
    echo "Local WordPress and Agah initialization complete.\n";
}catch(Throwable $e){fwrite(STDERR,'Local initialization error: '.get_class($e).' — '.$e->getMessage()."\n");exit(1);}
