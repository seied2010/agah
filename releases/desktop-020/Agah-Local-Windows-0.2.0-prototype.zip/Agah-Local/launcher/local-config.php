<?php
// This wrapper config is copied outside the web root. Application sources are unchanged.
$local=json_decode(file_get_contents(__DIR__.'/settings.json'),true,512,JSON_THROW_ON_ERROR);
define('DB_NAME','agah_local');define('DB_USER','agah_local');define('DB_PASSWORD',$local['db_password']);
define('DB_HOST',$local['db_host'].':'.$local['db_port']);define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');
$table_prefix='wp_';
foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $key)define($key,hash_hmac('sha512',$key,$local['salts']));
define('AGAH_ENC_KEY',$local['enc_key']);
define('WP_HOME',$local['url']);define('WP_SITEURL',$local['url']);
define('WP_ENVIRONMENT_TYPE','local');define('WP_DEBUG',false);define('DISABLE_WP_CRON',true);
define('WP_HTTP_BLOCK_EXTERNAL',true);define('WP_ACCESSIBLE_HOSTS','127.0.0.1,localhost');
define('AUTOMATIC_UPDATER_DISABLED',true);define('DISALLOW_FILE_EDIT',true);define('DISALLOW_FILE_MODS',true);
define('WP_AUTO_UPDATE_CORE',false);
unset($local);
