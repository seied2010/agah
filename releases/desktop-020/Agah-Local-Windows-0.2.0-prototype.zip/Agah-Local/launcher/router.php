<?php
$host=$_SERVER['HTTP_HOST']??'';
if(!preg_match('/^(127\.0\.0\.1|localhost):18817$/D',$host)){http_response_code(403);exit('Local access only.');}
$path=rawurldecode(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)??'/');
if(strpos($path,"\0")!==false||strpos($path,'\\')!==false||preg_match('~(^|/)\.\.?(?:/|$)~',$path)){http_response_code(400);exit;}
$app=dirname(__DIR__).'/app';
if(is_file($app.$path)||is_dir($app.$path))return false;
require $app.'/index.php';
