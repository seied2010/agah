<?php
$required=['mysqli','mbstring','sodium','openssl','curl','zip','gd','fileinfo','zlib'];
$missing=array_filter($required,function($e){return !extension_loaded($e);});
if(PHP_VERSION_ID<80300||$missing||!class_exists('DOMDocument')||!class_exists('SimpleXMLElement')){fwrite(STDERR,'Runtime preflight failed: PHP 8.3+, DOM/SimpleXML and '.implode(',',$missing)." required.\n");exit(1);}
echo "PHP runtime extensions ready.\n";
