$state = Join-Path $env:LOCALAPPDATA 'AgahLocalPrototype\state'
if (-not (Test-Path $state)) { Write-Host 'No local installation found.'; exit 0 }
[IO.File]::WriteAllText((Join-Path $state 'stop.request'), 'stop')
Write-Host 'Clean shutdown requested. Wait for the Agah Local console to close before backing up files.'
