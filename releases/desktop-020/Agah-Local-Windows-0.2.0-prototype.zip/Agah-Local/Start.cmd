@echo off
setlocal
if exist "%LOCALAPPDATA%\AgahLocalPrototype\program\launcher\run.ps1" (
 powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\AgahLocalPrototype\program\launcher\run.ps1"
) else (
 call "%~dp0Install.cmd"
)
if errorlevel 1 pause
