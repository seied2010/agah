<?php
/** داشبورد و جست‌وجوی واقعی با فیلتر شرکت/مجوز؛ اعلان‌ها از سررسید/حداقل ثبت‌شده خوانده می‌شوند. */
namespace Agah\Erp\Modules\Dashboard;
use Agah\Erp\Core\{Access,Business,Ctx,Db,Jalali,Money,Request};
use Agah\Erp\Modules\Accounting\FinancialService;
use Agah\Erp\Security\RateLimiter;
if(!defined('ABSPATH'))exit;
final class DashboardService {
    /** Read-only period cards shared by clients; posting and financial validation remain unchanged. */
    public static function period($cid,$from,$to) {
        Access::need($cid,'dashboard.view');Business::date($from);Business::date($to);
        $fy=\Agah\Erp\Modules\Accounting\FiscalService::forDate($cid,$to);
        if(!$fy||$from<$fy['start_date']||$from>$to)throw new \Agah\Erp\Core\ValidationException(['from'=>'بازهٔ داشبورد باید در یک سال مالی باشد.']);
        return Db::tx(function () use ($cid,$from,$to,$fy) {
            $cards=[];$filters=['from'=>$from,'to'=>$to,'status'=>'issued','fiscal_year_id'=>$fy['id']];
            foreach(['sale'=>'فروش خالص بازه (با مالیات)','purchase'=>'خرید خالص بازه (با مالیات)'] as $kind=>$label) {
                if(!Ctx::can(\Agah\Erp\Modules\Trade\InvoiceService::resource($kind).'.view'))continue;
                $cards[$label]=FinancialService::integer(Db::val('SELECT COALESCE(SUM(IF(kind=%s,CAST(amount AS SIGNED),-CAST(amount AS SIGNED))),0) FROM '.Db::t('invoices')." WHERE company_id=%d AND fiscal_year_id=%d AND kind IN (%s,%s) AND status='issued' AND invoice_date BETWEEN %s AND %s",$kind,$cid,$fy['id'],$kind,$kind.'_return',$from,$to));
            }
            foreach(['receipt'=>'دریافت بازه','payment'=>'پرداخت بازه'] as $kind=>$label) {
                if(!Ctx::can($kind.'.view'))continue;
                $cards[$label]=FinancialService::integer(Db::val('SELECT COALESCE(SUM(amount),0) FROM '.Db::t('treasury_docs')." WHERE company_id=%d AND fiscal_year_id=%d AND kind=%s AND status='issued' AND doc_date BETWEEN %s AND %s",$cid,$fy['id'],$kind,$from,$to));
            }
            if(Ctx::can('expense.view')) {
                $totals=\Agah\Erp\Modules\Expenses\ExpenseService::page($cid,$filters,1)['total'];
                $cards['هزینه متفرقه بازه']=FinancialService::integer($totals['expenses']);$cards['درآمد متفرقه بازه']=FinancialService::integer($totals['income']);
            }
            if(Ctx::can('treasury_account.view'))$cards['موجودی بانک و صندوق در پایان بازه']=self::ledgerTotal($cid,['cash','bank'],$to);
            if(Ctx::can('stock.view'))$cards['ارزش موجودی فعلی انبار (تمام دوره‌ها)']=FinancialService::integer(Db::val('SELECT COALESCE(SUM(cost),0) FROM '.Db::t('stock_moves')." WHERE company_id=%d AND status='active'",$cid));
            if(Ctx::can('report.view')) {
                $cards['مانده دریافتنی تجاری در پایان بازه']=self::ledgerTotal($cid,['receivable','notes_receivable'],$to);
                $cards['مانده پرداختنی تجاری در پایان بازه']=-self::ledgerTotal($cid,['payable','notes_payable'],$to);
                $cards['سود خالص بازه (دفتر)']=FinancialService::profitInternal($cid,$from,$to)['net'];
            }
            return ['cards'=>$cards,'from'=>$from,'to'=>$to];
        });
    }
    public static function summary($cid,$today=''){
        Access::need($cid,'dashboard.view');$today=$today?:Jalali::today();Business::date($today);$j=Jalali::fromDb($today);$year=$j[0];$month=$j[1];$months=[];
        for($back=5;$back>=0;$back--){$y=$year;$m=$month-$back;while($m<1){$m+=12;$y--;}$r=Jalali::monthsOf($y)[$m-1];$months[]=$r+['label'=>$r['name'].' '.$y,'sale'=>0,'purchase'=>0,'expense'=>0,'income'=>0];}
        $cases=[];$ranges=[];foreach($months as $idx=>$m){$cases[]='WHEN %s<=doc_date AND doc_date<=%s THEN '.$idx;$ranges[]=$m['start'];$ranges[]=$m['end'];}
        $case='CASE '.implode(' ',$cases).' ELSE -1 END';$records=false;
        $sales=Ctx::can('sale_invoice.view');$purchases=Ctx::can('purchase_invoice.view');$expenses=Ctx::can('expense.view');
        if($sales||$purchases){$query="SELECT kind,$case AS period,SUM(amount) AS amount FROM (SELECT kind,invoice_date AS doc_date,IF(kind IN ('sale_return','purchase_return'),-CAST(amount AS SIGNED),CAST(amount AS SIGNED)) AS amount FROM ".Db::t('invoices')." WHERE company_id=%d AND status='issued' AND invoice_date BETWEEN %s AND %s) docs GROUP BY kind,period";
            foreach(Db::rows($query,...array_merge($ranges,[$cid,$months[0]['start'],$today])) as $r){$records=true;$key=strpos($r['kind'],'purchase')===0?'purchase':'sale';if(($key==='sale'&&!$sales)||($key==='purchase'&&!$purchases))continue;$idx=(int)$r['period'];if($idx>=0)$months[$idx][$key]=Money::add($months[$idx][$key],FinancialService::integer($r['amount']));}
        }
        if($expenses){$query="SELECT kind,$case AS period,SUM(amount) AS amount FROM ".Db::t('expense_docs')." WHERE company_id=%d AND status='issued' AND doc_date BETWEEN %s AND %s GROUP BY kind,period";foreach(Db::rows($query,...array_merge($ranges,[$cid,$months[0]['start'],$today])) as $r){$records=true;$idx=(int)$r['period'];if($idx>=0)$months[$idx][$r['kind']]=FinancialService::integer($r['amount']);}}
        $cards=[];if($sales)$cards['فروش خالص ماه (با مالیات)']=$months[5]['sale'];if($purchases)$cards['خرید خالص ماه (با مالیات)']=$months[5]['purchase'];if($expenses){$cards['هزینه متفرقه ماه']=$months[5]['expense'];$cards['درآمد متفرقه ماه']=$months[5]['income'];}
        if(Ctx::can('treasury_account.view'))$cards['موجودی بانک و صندوق']=self::ledgerTotal($cid,['cash','bank'],$today);
        if(Ctx::can('report.view')){$cards['مانده دریافتنی تجاری']=self::ledgerTotal($cid,['receivable','notes_receivable'],$today);$cards['مانده پرداختنی تجاری']=-self::ledgerTotal($cid,['payable','notes_payable'],$today);$cards['سود خالص ماه (دفتر)']=FinancialService::profitInternal($cid,$months[5]['start'],$today)['net'];}
        return ['cards'=>$cards,'months'=>$months,'visible'=>['sale'=>$sales,'purchase'=>$purchases,'expense'=>$expenses,'income'=>$expenses],'date'=>$today,'has_records'=>$records];
    }
    private static function ledgerTotal($cid,$keys,$date){$fy=\Agah\Erp\Modules\Accounting\FiscalService::forDate($cid,$date);if(!$fy)throw new \Agah\Erp\Core\ValidationException(['date'=>'سال مالی تاریخ داشبورد وجود ندارد.']);$slots=implode(',',array_fill(0,count($keys),'%s'));return FinancialService::integer(Db::val('SELECT COALESCE(SUM(CAST(l.debit AS SIGNED)-CAST(l.credit AS SIGNED)),0) FROM '.Db::t('voucher_lines').' l JOIN '.Db::t('vouchers').' v ON v.company_id=l.company_id AND v.id=l.voucher_id JOIN '.Db::t('accounts')." a ON a.company_id=l.company_id AND a.id=l.account_id WHERE v.company_id=%d AND v.fiscal_year_id=%d AND v.voucher_date<=%s AND v.status IN ('approved','final') AND a.sys_key IN ($slots)",...array_merge([$cid,$fy['id'],$date],$keys)));}
    /** حداکثر ۲۵ مورد از هر گروه؛ فاکتور تسویه‌شده اعلان معوق نمی‌سازد. */
    public static function notifications($cid,$today=''){
        Access::need($cid,'dashboard.view');$today=$today?:Jalali::today();Business::date($today);$out=[];$kinds=[];if(Ctx::can('sale_invoice.view'))$kinds[]='sale';if(Ctx::can('purchase_invoice.view'))$kinds[]='purchase';
        if($kinds){$slots=implode(',',array_fill(0,count($kinds),'%s'));
            $query='SELECT i.id,i.number,i.kind,i.due_date,CAST(i.amount AS SIGNED)-COALESCE(r.amount,0)-COALESCE(s.amount,0)-COALESCE(a.amount,0)+COALESCE(f.amount,0) AS outstanding FROM '.Db::t('invoices')." i LEFT JOIN (SELECT company_id,parent_id,SUM(amount) amount FROM ".Db::t('invoices')." WHERE company_id=%d AND status='issued' AND kind IN ('sale_return','purchase_return') GROUP BY company_id,parent_id) r ON r.company_id=i.company_id AND r.parent_id=i.id LEFT JOIN (SELECT company_id,invoice_id,SUM(amount) amount FROM ".Db::t('settlements')." WHERE company_id=%d AND status='active' GROUP BY company_id,invoice_id) s ON s.company_id=i.company_id AND s.invoice_id=i.id LEFT JOIN (SELECT company_id,invoice_id,SUM(amount) amount FROM ".Db::t('invoice_advances')." WHERE company_id=%d AND status='active' GROUP BY company_id,invoice_id) a ON a.company_id=i.company_id AND a.invoice_id=i.id LEFT JOIN (SELECT s.company_id,t.parent_id,SUM(s.amount) amount FROM ".Db::t('settlements').' s JOIN '.Db::t('invoices')." t ON t.company_id=s.company_id AND t.id=s.invoice_id WHERE s.company_id=%d AND s.status='active' AND t.status='issued' AND t.kind IN ('sale_return','purchase_return') GROUP BY s.company_id,t.parent_id) f ON f.company_id=i.company_id AND f.parent_id=i.id WHERE i.company_id=%d AND i.status='issued' AND i.kind IN ($slots) AND i.due_date<%s HAVING outstanding>0 ORDER BY i.due_date,i.id LIMIT 25";
            foreach(Db::rows($query,...array_merge(array_fill(0,5,$cid),$kinds,[$today])) as $r)$out[]=['type'=>'invoice','title'=>($r['kind']==='sale'?'مطالبه':'بدهی').' معوق #'.$r['number'],'date'=>$r['due_date'],'amount'=>FinancialService::integer($r['outstanding']),'page'=>'invoice_view','id'=>$r['id']];
        }
        if(Ctx::can('cheque.view'))foreach(Db::rows('SELECT id,cheque_no,due_date,amount FROM '.Db::t('cheques')." WHERE company_id=%d AND status='pending' AND due_date<=%s ORDER BY due_date,id LIMIT 25",$cid,$today) as $r)$out[]=['type'=>'cheque','title'=>'چک سررسیدشده '.$r['cheque_no'],'date'=>$r['due_date'],'amount'=>(int)$r['amount'],'page'=>'cheques'];
        if(Ctx::can('stock.view'))foreach(Db::rows('SELECT n.warehouse_id,n.item_id,i.name,COALESCE(SUM(m.qty_scaled),0) AS qty,n.qty_scaled AS minimum FROM '.Db::t('stock_minimums').' n JOIN '.Db::t('items').' i ON i.company_id=n.company_id AND i.id=n.item_id LEFT JOIN '.Db::t('stock_moves')." m ON m.company_id=n.company_id AND m.warehouse_id=n.warehouse_id AND m.item_id=n.item_id AND m.status='active' WHERE n.company_id=%d GROUP BY n.warehouse_id,n.item_id,i.name,n.qty_scaled HAVING qty<minimum ORDER BY n.warehouse_id,n.item_id LIMIT 25",$cid) as $r)$out[]=['type'=>'stock','title'=>'کمبود موجودی '.$r['name'],'date'=>'','page'=>'inventory','warehouse_id'=>$r['warehouse_id'],'item_id'=>$r['item_id']];
        if(Ctx::can('tax_rate.view')){$n=(int)Db::val('SELECT COUNT(*) FROM '.Db::t('items').' i JOIN '.Db::t('tax_rates')." t ON t.company_id=i.company_id AND t.id=i.tax_rate_id WHERE i.company_id=%d AND i.is_active=1 AND (t.confirmed=0 OR t.bp IS NULL)",$cid);if($n)$out[]=['type'=>'tax','title'=>'کالا با نرخ تأییدنشده: '.$n,'date'=>'','page'=>'taxes'];}
        return $out;
    }
    /** جست‌وجوی نام/کد با سقف و سهمیه؛ هر نوع نتیجه پیش از کوئری cap مستقل دارد. */
    public static function search($cid,$q){
        Access::need($cid,'dashboard.view');$q=Request::clean($q,100);if(preg_match('/^[۰-۹٠-٩0-9٬,]+$/u',$q))$q=Money::normDigits($q);if($q===''||(mb_strlen($q)<2&&!ctype_digit($q)))return [];
        if(!RateLimiter::consume('global-search|'.Ctx::uid().'|'.$cid,60,60))throw new \Agah\Erp\Core\ConflictException('جست‌وجو بیش از حد مجاز است.');global $wpdb;$like='%'.$wpdb->esc_like($q).'%';$out=[];
        foreach(['parties'=>['party.view','party_view'],'items'=>['item.view','items'],'vouchers'=>['voucher.view','voucher_view']] as $table=>$meta){if(!Ctx::can($meta[0]))continue;$column=$table==='vouchers'?'description':'name';$code=$table==='vouchers'?'number':'code';foreach(Db::rows('SELECT id,'.$column.' AS label,'.$code.' AS code FROM '.Db::t($table).' WHERE company_id=%d AND ('.$column.' LIKE %s OR CAST('.$code.' AS CHAR) LIKE %s) ORDER BY id DESC LIMIT 12',$cid,$like,$like) as $r)$out[]=['type'=>$table,'title'=>$r['code'].' — '.$r['label'],'page'=>$meta[1],$table==='items'?'edit':'id'=>$r['id']];}
        $kinds=[];foreach(\Agah\Erp\Modules\Trade\InvoiceService::KINDS as $kind=>$label)if(Ctx::can(\Agah\Erp\Modules\Trade\InvoiceService::resource($kind).'.view'))$kinds[]=$kind;
        if($kinds){$slots=implode(',',array_fill(0,count($kinds),'%s'));foreach(Db::rows('SELECT i.id,i.number,i.kind,p.name FROM '.Db::t('invoices').' i JOIN '.Db::t('parties')." p ON p.company_id=i.company_id AND p.id=i.party_id WHERE i.company_id=%d AND i.kind IN ($slots) AND (CAST(i.number AS CHAR) LIKE %s OR p.name LIKE %s OR i.description LIKE %s) ORDER BY i.id DESC LIMIT 12",...array_merge([$cid],$kinds,[$like,$like,$like])) as $r)$out[]=['type'=>'invoice','title'=>\Agah\Erp\Modules\Trade\InvoiceService::KINDS[$r['kind']].' #'.$r['number'].' — '.$r['name'],'page'=>'invoice_view','id'=>$r['id']];}
        return $out;
    }
}
